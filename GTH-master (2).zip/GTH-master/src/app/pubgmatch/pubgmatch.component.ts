import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pubgmatch',
  templateUrl: './pubgmatch.component.html',
  styleUrls: ['./pubgmatch.component.css']
})
export class PubgmatchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
