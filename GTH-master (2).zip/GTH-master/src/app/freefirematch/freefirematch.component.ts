import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-freefirematch',
  templateUrl: './freefirematch.component.html',
  styleUrls: ['./freefirematch.component.css']
})
export class FreefirematchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
