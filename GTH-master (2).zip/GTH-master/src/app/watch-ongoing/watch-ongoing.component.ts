import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-watch-ongoing',
  templateUrl: './watch-ongoing.component.html',
  styleUrls: ['./watch-ongoing.component.css']
})
export class WatchOngoingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
